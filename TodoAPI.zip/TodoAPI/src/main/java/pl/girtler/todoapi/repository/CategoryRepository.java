package pl.girtler.todoapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.girtler.todoapi.model.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {

}